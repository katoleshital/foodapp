package com.account.java.service;

import com.account.java.dto.AccountRequestDTO;

public interface AccountService {

	public String saveTransaction(AccountRequestDTO dto);

}
