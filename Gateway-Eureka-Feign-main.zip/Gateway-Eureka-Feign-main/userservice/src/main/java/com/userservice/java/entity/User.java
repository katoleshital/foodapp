package com.userservice.java.entity;

public class User {

	Integer ticketId;
	
}
