package com.trainservice.java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
